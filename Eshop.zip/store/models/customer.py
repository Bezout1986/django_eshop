from django.db import models

class Customer (models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    password = models.CharField(max_length=512, default='notentered')
    passworb = models.CharField(max_length=512, default='notentered')

    def regstr(self):
        self.save()

    @staticmethod
    def get_cust_by_email(email):
        try:
          return Customer.objects.get(email=email)
        except:
          return False


    def isexist(self):
        if Customer.objects.filter(email=self.email):
            return True
        else:
            return False