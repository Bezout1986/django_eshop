from django.shortcuts import render, HttpResponse, redirect,HttpResponseRedirect
import time
from .models.products import Products
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
from datetime import datetime
from store.middleware.auth import auth_middleware
from django.utils.decorators import method_decorator

def index(request):
    prod = None
    catg = Category.get_all_categories()
    categoryID = request.GET.get('qcategory')
    if categoryID:
        prod = Products.get_all_products_by_id(categoryID)
    else:
        prod = Products.get_all_products()

    print('seesion authentcicated for', request.session.get('customer_email'))

    data = {}
    data['products'] = prod
    data['categories'] = catg
    return render(request, 'index.html', data)


def signupf(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:

        reqfunc = request.POST.get
        fn = reqfunc('firstname')
        ln = reqfunc('lastname')
        ph = reqfunc('phone')
        em = reqfunc('email')
        pw = reqfunc('password')
        pb = reqfunc('passworb')

        errorbit = 0
        error_mssgpw = None
        if (pw != pb):
            error_mssgpw = 'Passwords do not match'
            errorbit = errorbit + 1
        value = {'fn': fn, 'ln': ln, 'ph': ph, 'em': em}
        pw = make_password(pw)
        cust = Customer(first_name=fn,
                        last_name=ln,
                        phone=ph,
                        email=em,
                        password=pw)

        error_mssgfn = None
        if (not fn):
            error_mssgfn = 'first name not wriiten'
            errorbit = errorbit + 1
        elif (fn) and (len(fn) < 5):
            error_mssgfn = 'length of first name shud be 5 atleast'
            errorbit = errorbit + 1

        error_mssgln = None
        if (not ln):
            error_mssgln = 'last name not wriiten'
            errorbit = errorbit + 1
        elif (ln) and (len(ln) < 5):
            error_mssgln = 'length of last name shud be 5 atleast'
            errorbit = errorbit + 1

        error_mssgph = None
        if (not ph):
            error_mssgph = 'phone not wriiten'
            errorbit = errorbit + 1
        elif (ph) and (len(ph) < 11):
            error_mssgph = 'mobile shuld be 10 atleast'
            errorbit = errorbit + 1

        error_mssgem = None
        if (not em):
            error_mssgem = 'email not entered'
            errorbit = errorbit + 1
        elif cust.isexist():
            error_mssgem = 'email already registered'
            errorbit = errorbit + 1

        if (errorbit == 0):
            cust.regstr()
            print(fn, ln, ph, em, pw)

            return render(request, 'homepage1.html')

        else:

            data = {'fn': fn, 'ln': ln, 'ph': ph, 'em': em, 'errorr_fn': error_mssgfn, 'errorr_ln': error_mssgln,
                    'errorr_ph': error_mssgph,
                    'errorr_em': error_mssgem, 'errorr_pw': error_mssgpw}

            return render(request, 'signup.html', data)


def login1(request):

    if request.method == 'GET':

        return render(request, 'login.html')
    else:
        l_email = request.POST.get('lemail')
        l_pw = request.POST.get('lpassword')
        customer = Customer.get_cust_by_email(l_email)

        if customer:
            err = None
            flag = check_password(l_pw, customer.password)
            if flag:
                request.session['customer_id'] = customer.id
                request.session['customer_email'] = customer.email

                return render(request, 'homepage1.html')
            else:
                err = 'Invalid credentials!'
                return render(request, 'login.html', {'errorr_lpw': err})
        else:
            err = 'customr does not exist!'
            return render(request, 'login.html', {'errorr_lpw': err})


def cart(request):
    if request.method == 'POST':
        prodcart = request.POST.get('prodcart')
        cartt = request.session.get('cartt')
        if cartt:
            quant=cartt.get(prodcart)
            if quant:
             cartt[prodcart]=quant+1

            else:
             cartt[prodcart]=1
        else:
            cartt = {}
            cartt[prodcart]=1

        request.session['cartt']=cartt
        print(prodcart)
        print(cartt)
        return redirect('homepage')

    elif request.method == 'GET':
        prod = None
        catg = Category.get_all_categories()
        categoryID = request.GET.get('qcategory')
        if categoryID:
            prod = Products.get_all_products_by_id(categoryID)
        else:
            prod = Products.get_all_products()

            print('seesion authentcicated fro inside cart fn', request.session.get('customer_email'))

            data = {}
            data['products'] = prod
            data['categories'] = catg

            return render(request, 'index.html', data)

def ncart(request):
    if request.method == 'POST':
        prodcart = request.POST.get('prodcart')
        cartt = request.session.get('cartt')
        quant=cartt.get(prodcart)
        if quant > 1:
          cartt[prodcart]=quant-1
        else:
          cartt.pop(prodcart)
        request.session['cartt']=cartt
        print(prodcart)
        print(cartt)
        return redirect('homepage')

    elif request.method == 'GET':
        prod = None
        catg = Category.get_all_categories()
        categoryID = request.GET.get('qcategory')
        if categoryID:
            prod = Products.get_all_products_by_id(categoryID)
        else:
            prod = Products.get_all_products()

            print('seesion authentcicated fro inside cart fn', request.session.get('customer_email'))

            data = {}
            data['products'] = prod
            data['categories'] = catg

            return render(request, 'index.html', data)

def callcart(request):
    print (list((request.session.get('cartt').keys())))
    ids =list(request.session.get('cartt').keys())
    products = Products.get_products_by_id(ids)
    print(products)
    data = {}
    data['prods'] = products
    return render(request, 'cart.html', data)

def logout(request):
    request.session.clear()
    return redirect('homepage')


class Checkout(View):
    def post(self,request):

        address=request.POST.get('address')
        phone=request.POST.get('phone')
        customer=request.session.get('customer_id')
        cart=request.session.get('cartt')
        products= Products.get_products_by_id(list(cart.keys()))
        print(address, phone, customer,cart, products)

        for product in products:
            order=Order(customer=Customer(id=customer), product=product, price=product.price , address=address, phone=phone, quantity=cart.get(str(product.id)))
            order.save();

        request.session['cartt']={}
        catg = Category.get_all_categories()
        prod = Products.get_all_products()
        data = {}
        data['products'] = prod
        data['categories'] = catg
        return render(request, 'index.html', data)

class OrderView(View):
    @method_decorator(auth_middleware)

    def get(self,request):
        customer = request.session.get('customer_id')
        orders = Order.get_orders_by_customer(customer)
        return render(request,'orders.html',{'orders':orders})