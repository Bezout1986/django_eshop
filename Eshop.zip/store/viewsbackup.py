from django.shortcuts import render, HttpResponse,  redirect
import time
from .models.products import Products
from .models.category import Category
from .models.customer import Customer
from django.contrib.auth.hashers import make_password, check_password



def index(request):
    prod = None
    catg = Category.get_all_categories()
    categoryID = request.GET.get('qcategory')
    if categoryID:
        prod = Products.get_all_products_by_id(categoryID)
    else:
        prod = Products.get_all_products()

    print(prod)
    print(catg)

    data = {}
    data['products'] = prod
    data['categories'] = catg
    return render(request, 'index.html', data)


def signupf(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:

        reqfunc = request.POST.get
        fn = reqfunc('firstname')
        ln = reqfunc('lastname')
        ph = reqfunc('phone')
        em = reqfunc('email')
        pw = reqfunc('password')
        pb = reqfunc('passworb')

        errorbit = 0
        error_mssgpw = None
        if (pw != pb):
            error_mssgpw = 'Passwords do not match'
            errorbit = errorbit+1
        value = {'fn': fn, 'ln': ln, 'ph': ph, 'em': em}
        pw=make_password(pw)
        cust = Customer(first_name=fn,
                        last_name=ln,
                        phone=ph,
                        email=em,
                        password=pw)


        error_mssgfn = None
        if (not fn):
            error_mssgfn = 'first name not wriiten'
            errorbit = errorbit + 1
        elif (fn) and (len(fn) < 5):
            error_mssgfn = 'length of first name shud be 5 atleast'
            errorbit = errorbit + 1

        error_mssgln = None
        if (not ln):
            error_mssgln = 'last name not wriiten'
            errorbit = errorbit + 1
        elif (ln) and (len(ln) < 5):
            error_mssgln = 'length of last name shud be 5 atleast'
            errorbit = errorbit + 1

        error_mssgph = None
        if (not ph):
            error_mssgph = 'phone not wriiten'
            errorbit = errorbit + 1
        elif (ph) and (len(ph) < 11):
            error_mssgph = 'mobile shuld be 10 atleast'
            errorbit = errorbit + 1

        error_mssgem = None
        if (not em):
            error_mssgem = 'email not entered'
            errorbit = errorbit + 1
        elif cust.isexist():
            error_mssgem = 'email already registered'
            errorbit = errorbit + 1


        if (errorbit == 0):
            cust.regstr()
            print(fn, ln, ph, em, pw)

            return render(request, 'homepage1.html')




        else:

            data= {'fn': fn, 'ln': ln, 'ph': ph, 'em': em ,'errorr_fn': error_mssgfn, 'errorr_ln': error_mssgln, 'errorr_ph': error_mssgph,
             'errorr_em': error_mssgem, 'errorr_pw':error_mssgpw}

            return render(request, 'signup.html',data)
